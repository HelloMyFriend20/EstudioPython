def potenciar (op1, op2):
    print(f'El resultado de la potencia es: {op1**op2}')

def redondear(numero):
    print(f'El resultado es: {round(numero)}')