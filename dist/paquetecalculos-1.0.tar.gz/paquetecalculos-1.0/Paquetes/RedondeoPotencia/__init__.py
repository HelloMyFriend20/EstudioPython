#Son directorios donde se almacenaran modulos relacionados entre sí.
#Sirven para organizar y reutilizar los módulos.
#Creamos una carpeta con un archivo __init__.py

