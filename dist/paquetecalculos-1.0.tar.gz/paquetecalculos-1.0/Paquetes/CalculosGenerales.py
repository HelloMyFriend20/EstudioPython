#Como usamos este modulo desde otra carpeta.
def sumar (op1, op2):
    print(f'El resultado de la suma es: {op1+op2}')

def restar (op1, op2):
    print(f'El resultado de la resta es: {op1-op2}')

def multiplicar (op1, op2):
    print(f'El resultado de la multiplicación es: {op1*op2}')

def dividir (op1, op2):
    print(f'El resultado de la division es: {op1/op2}')

def potenciar (op1, op2):
    print(f'El resultado de la potencia es: {op1**op2}')

def redondear(numero):
    print(f'El resultado es: {round(numero)}')