#Archivo correspondiente al tema Paquetes distribuibles, video 36
from setuptools import setup

setup(
    name = "paquetecalculos",
    version = "1.0",
    description = "Paquete de redondeo y potencia",
    author = "Martin",
    author_email = "maferaro2018@gmail.com",
    url = "https://github.com/HelloMyFriend20/EstudioPython",
    packages = ["Paquetes","Paquetes.RedondeoPotencia"]
)